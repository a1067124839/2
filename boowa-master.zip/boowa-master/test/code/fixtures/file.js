module.exports = {
  metadata: {
    title: 'A title',
    readingTime: 'xx min read'
  },
  contents: 'some contents'
}
