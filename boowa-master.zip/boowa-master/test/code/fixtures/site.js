module.exports = {
  files: [
    {
      history: [
        '/Users/zhouhancheng/编程/boowa-blog/code/_articles/.DS_Store',
        '.DS_Store',
        '/Users/zhouhancheng/编程/boowa-blog/code/app/articles/.DS_Store'
      ]
    },
    {
      history: [
        '/Users/zhouhancheng/编程/boowa-blog/code/_articles/sheetify_document.md',
        'sheetify_document.md',
        'sheetify_document.html',
        '/Users/zhouhancheng/编程/boowa-blog/code/app/articles/sheetify_document.html'
      ],
      metadata: {
        title: 'sheetify document',
        readingTime: '10 min read'
      }
    }
  ]
}
