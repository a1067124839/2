var generateArticleScript = require('./generateArticleScript')

module.exports = () => {
  generateArticleScript()
}
