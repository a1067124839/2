var code = require('./code')
var austere = require('./austere')
var common = require('./common')

code()
austere()
common()
